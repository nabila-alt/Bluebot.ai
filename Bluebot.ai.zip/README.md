# BlueBot AI

Website AI Node.js dengan tema putih-biru minimalis, robot 3D-style berbasis CSS, chat, loading dots, registrasi, login, dan verifikasi email OTP melalui Brevo.

## Persyaratan
- Node.js 20 atau lebih baru
- Akun Brevo dengan transactional email aktif dan sender email yang sudah diverifikasi
- Endpoint AI yang sah dan dapat diakses oleh server. Kode memakai format OpenAI-compatible `POST /chat/completions` secara default.

## Instalasi lokal / hosting Node.js
```bash
npm install
cp .env.example .env
```
Isi `.env`:
- `SESSION_SECRET`: string acak panjang minimal 32 karakter.
- `BREVO_API_KEY`: API key Brevo transactional email.
- `BREVO_SENDER_EMAIL`: alamat sender yang sudah diverifikasi di Brevo.
- `AI_BASE_URL`: base URL provider AI.
- `AI_MODEL`: model yang disediakan provider.
- `AI_CHAT_COMPLETIONS_PATH`: default `/chat/completions`. Atur sesuai dokumentasi provider.

Lalu jalankan:
```bash
npm start
```
Buka `http://localhost:3000`.

## Contoh konfigurasi endpoint
Jika provider memberi base URL `https://api.example.com/v1` dan mendukung format OpenAI-compatible:
```env
AI_BASE_URL=https://api.example.com/v1
AI_MODEL=nama-model-dari-provider
AI_CHAT_COMPLETIONS_PATH=/chat/completions
```
Jangan menebak base URL/model. Endpoint tanpa API key hanya bisa dipakai jika pemilik provider memang mengizinkannya. Jika provider memiliki format request/response berbeda, sesuaikan bagian `app.post('/api/chat'...)` di `server.js`.

## Deploy
Pilih layanan hosting yang mendukung Node.js 20 dan proses server persisten. Set environment variables lewat dashboard hosting; jangan upload `.env` ke GitHub. Jalankan `npm install` dan `npm start`, dan arahkan port publik ke nilai `PORT` yang disediakan hosting.

## Catatan keamanan penting
- OTP berlaku 10 menit, dibatasi 5 percobaan, dan ada rate limit.
- Password di-hash menggunakan bcrypt.
- OTP disimpan sebagai hash.
- Endpoint AI dipanggil tanpa header API key; gunakan hanya endpoint yang memang mengizinkan akses tanpa autentikasi.
- Database JSON cocok untuk starter satu instance, tetapi bukan database produksi untuk multi-instance. Untuk penggunaan serius, ganti dengan SQLite/PostgreSQL dan gunakan session store persisten seperti Redis/DB.
- `express-session` default MemoryStore tidak cocok untuk produksi skala besar. Gunakan session store persisten saat deployment produksi.
- Wajib gunakan HTTPS pada deployment publik dan isi `SESSION_SECRET` yang kuat.
- Implementasi ini sengaja tidak meminta password Gmail pengguna. OTP dikirim dari akun sender milik pemilik website lewat Brevo.
