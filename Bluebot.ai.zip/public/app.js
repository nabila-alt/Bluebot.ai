const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const authView = $('#auth-view');
const chatView = $('#chat-view');
const authMessage = $('#auth-message');
const toast = $('#toast');
const messagesEl = $('#messages');
const chatScroll = $('#chat-scroll');
const welcomeCard = $('#welcome-card');
const chatInput = $('#chat-input');
const sendBtn = $('#send-btn');
const charCount = $('#char-count');
let pendingEmail = '';
let currentUser = null;
let toastTimer;
let robotTimer;
let robotIndex = 0;
const robotLines = [
  'Hai! Aku siap membantu ide kamu.',
  'Mau bikin proyek apa hari ini?',
  'Ceritakan idemu, kita mulai bersama.',
  'Aku bisa bantu menulis dan coding.',
  'Tulis pertanyaanmu di kolom bawah, ya!'
];

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add('hidden'), 3400);
}
function showAuthMessage(message, success = false) {
  authMessage.textContent = message;
  authMessage.classList.toggle('success', success);
  authMessage.classList.remove('hidden');
}
function clearAuthMessage() { authMessage.classList.add('hidden'); authMessage.textContent = ''; }
function setAuthTab(tab) {
  clearAuthMessage();
  $$('.auth-tab').forEach(button => button.classList.toggle('active', button.dataset.authTab === tab));
  $('#login-panel').classList.toggle('hidden', tab !== 'login');
  $('#register-panel').classList.toggle('hidden', tab !== 'register');
  $('#otp-panel').classList.add('hidden');
}
function setBusy(button, busy, label = 'Memproses...') {
  if (busy) { button.dataset.originalText = button.innerHTML; button.disabled = true; button.textContent = label; }
  else { button.disabled = false; if (button.dataset.originalText) button.innerHTML = button.dataset.originalText; }
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request gagal (${response.status})`);
  return data;
}
function showOtp(email) {
  pendingEmail = email;
  clearAuthMessage();
  $$('.auth-panel').forEach(panel => panel.classList.add('hidden'));
  $('#otp-panel').classList.remove('hidden');
  $$('.auth-tab').forEach(button => button.classList.remove('active'));
  $('#otp-email').textContent = email;
  const inputs = $$('.otp-inputs input');
  inputs.forEach(input => input.value = '');
  inputs[0].focus();
}
function showDashboard(user) {
  currentUser = user;
  authView.classList.add('hidden');
  chatView.classList.remove('hidden');
  $('#logout-btn').classList.remove('hidden');
  $('#user-label').classList.remove('hidden');
  $('#user-label').textContent = user.username;
  $('#welcome-name').textContent = user.username;
  loadHistory();
  startRobotTyping();
}
function showAuth() {
  currentUser = null;
  chatView.classList.add('hidden');
  authView.classList.remove('hidden');
  $('#logout-btn').classList.add('hidden');
  $('#user-label').classList.add('hidden');
  stopRobotTyping();
  setAuthTab('login');
}
function startRobotTyping() {
  stopRobotTyping();
  const target = $('#robot-text');
  let char = 0, deleting = false;
  target.textContent = '';
  robotTimer = setInterval(() => {
    const line = robotLines[robotIndex];
    if (!deleting) {
      char++;
      target.textContent = line.slice(0, char);
      if (char >= line.length) {
        deleting = true;
        setTimeout(() => {}, 500);
      }
    } else {
      char--;
      target.textContent = line.slice(0, Math.max(0, char));
      if (char <= 0) {
        deleting = false;
        robotIndex = (robotIndex + 1) % robotLines.length;
      }
    }
  }, 75);
}
function stopRobotTyping() { if (robotTimer) clearInterval(robotTimer); robotTimer = null; }
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}
function addMessage(role, content, { pending = false } = {}) {
  const row = document.createElement('div');
  row.className = `message ${role}${pending ? ' pending' : ''}`;
  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = role === 'user' ? (currentUser?.username?.slice(0, 1).toUpperCase() || 'K') : 'B';
  const body = document.createElement('div');
  body.className = 'message-content';
  if (pending) {
    body.innerHTML = '<span>Sedang berpikir</span><span class="loading-dots" aria-label="Memuat"><i></i><i></i><i></i></span>';
    row.setAttribute('aria-label', 'AI sedang memproses jawaban');
  } else {
    body.textContent = content;
  }
  row.append(avatar, body);
  messagesEl.append(row);
  chatScroll.scrollTop = chatScroll.scrollHeight;
  return row;
}
function showChatMessages(messages) {
  messagesEl.replaceChildren();
  const hasMessages = messages.length > 0;
  welcomeCard.classList.toggle('hidden', hasMessages);
  messages.forEach(message => addMessage(message.role === 'assistant' ? 'assistant' : 'user', message.content));
  chatScroll.scrollTop = chatScroll.scrollHeight;
}
async function loadHistory() {
  try {
    const data = await api('/api/chat/history');
    showChatMessages(data.messages || []);
  } catch (error) {
    if (/login|verifikasi/i.test(error.message)) showAuth();
    else showToast(error.message);
  }
}
function startNewChat() {
  showChatMessages([]);
  chatInput.value = '';
  updateComposer();
  chatInput.focus();
}
function updateComposer() {
  chatInput.style.height = 'auto';
  chatInput.style.height = `${Math.min(chatInput.scrollHeight, 160)}px`;
  charCount.textContent = `${chatInput.value.length} / 6000`;
}
$$('[data-auth-tab]').forEach(button => button.addEventListener('click', () => setAuthTab(button.dataset.authTab)));
$$('[data-switch]').forEach(button => button.addEventListener('click', () => setAuthTab(button.dataset.switch)));

$('#register-form').addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  setBusy(button, true, 'Mengirim OTP...');
  try {
    const result = await api('/api/auth/register', { method: 'POST', body: JSON.stringify(values) });
    showOtp(result.email);
    showAuthMessage(result.message, true);
  } catch (error) { showAuthMessage(error.message); }
  finally { setBusy(button, false); }
});
$('#login-form').addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  setBusy(button, true, 'Memeriksa...');
  try {
    const result = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(values) });
    showDashboard(result.user);
  } catch (error) { showAuthMessage(error.message); }
  finally { setBusy(button, false); }
});
const otpInputs = $$('.otp-inputs input');
otpInputs.forEach((input, index) => {
  input.addEventListener('input', () => {
    input.value = input.value.replace(/\D/g, '').slice(-1);
    if (input.value && index < otpInputs.length - 1) otpInputs[index + 1].focus();
  });
  input.addEventListener('keydown', event => {
    if (event.key === 'Backspace' && !input.value && index > 0) otpInputs[index - 1].focus();
    if (event.key === 'ArrowLeft' && index > 0) otpInputs[index - 1].focus();
    if (event.key === 'ArrowRight' && index < otpInputs.length - 1) otpInputs[index + 1].focus();
  });
  input.addEventListener('paste', event => {
    const pasted = event.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!pasted) return;
    event.preventDefault();
    pasted.split('').forEach((digit, i) => { if (otpInputs[i]) otpInputs[i].value = digit; });
    otpInputs[Math.min(pasted.length, 5)].focus();
  });
});
$('#otp-form').addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button[type="submit"]');
  const otp = otpInputs.map(input => input.value).join('');
  if (otp.length !== 6) return showAuthMessage('Masukkan semua 6 digit OTP.');
  setBusy(button, true, 'Memverifikasi...');
  try {
    const result = await api('/api/auth/verify-otp', { method: 'POST', body: JSON.stringify({ email: pendingEmail, otp }) });
    showDashboard(result.user);
  } catch (error) { showAuthMessage(error.message); }
  finally { setBusy(button, false); }
});
$('#resend-otp').addEventListener('click', async event => {
  const button = event.currentTarget;
  setBusy(button, true, 'Mengirim ulang...');
  try {
    const result = await api('/api/auth/resend-otp', { method: 'POST', body: JSON.stringify({ email: pendingEmail }) });
    showAuthMessage(result.message, true);
  } catch (error) { showAuthMessage(error.message); }
  finally { setBusy(button, false); }
});
$('#back-register').addEventListener('click', () => setAuthTab('register'));
$('#logout-btn').addEventListener('click', async () => {
  try { await api('/api/auth/logout', { method: 'POST', body: '{}' }); } catch {}
  showAuth();
});
$('#new-chat').addEventListener('click', startNewChat);
$('#clear-chat').addEventListener('click', async () => {
  if (!confirm('Hapus semua riwayat percakapan?')) return;
  try {
    await api('/api/chat/history', { method: 'DELETE' });
    startNewChat();
    showToast('Riwayat percakapan dihapus.');
  } catch (error) { showToast(error.message); }
});
$('#attach-btn').addEventListener('click', () => showToast('Kamu bisa langsung mengetik pesan di kolom chat.'));
chatInput.addEventListener('input', updateComposer);
chatInput.addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    $('#chat-form').requestSubmit();
  }
});
$('#chat-form').addEventListener('submit', async event => {
  event.preventDefault();
  const message = chatInput.value.trim();
  if (!message || sendBtn.disabled) return;
  welcomeCard.classList.add('hidden');
  addMessage('user', message);
  chatInput.value = '';
  updateComposer();
  sendBtn.disabled = true;
  const pending = addMessage('assistant', '', { pending: true });
  try {
    const result = await api('/api/chat', { method: 'POST', body: JSON.stringify({ message }) });
    pending.remove();
    addMessage('assistant', result.answer);
  } catch (error) {
    pending.remove();
    addMessage('assistant', `Maaf, pesan belum bisa diproses.\n\n${error.message}`);
  } finally {
    sendBtn.disabled = false;
    chatInput.focus();
  }
});
$$('[data-prompt]').forEach(button => button.addEventListener('click', () => {
  chatInput.value = button.dataset.prompt;
  updateComposer();
  chatInput.focus();
}));

(async function init() {
  try {
    const result = await api('/api/auth/me');
    showDashboard(result.user);
  } catch {
    showAuth();
  }
})();
