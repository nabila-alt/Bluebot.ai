import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import { rateLimit } from 'express-rate-limit';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const OTP_TTL_MS = 10 * 60 * 1000;
const MAX_OTP_ATTEMPTS = 5;

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.warn('WARNING: Set SESSION_SECRET to a random value at least 32 characters long in .env.');
}
if (process.env.NODE_ENV === 'production') app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null
    }
  }
}));
app.use(express.json({ limit: '30kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(session({
  name: 'bluebot.sid',
  secret: process.env.SESSION_SECRET || crypto.randomBytes(48).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 24
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false });
const otpLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: 'draft-7', legacyHeaders: false });
const chatLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false });

let db = { users: [], pending: {}, chats: {} };
await fs.mkdir(DATA_DIR, { recursive: true });
try {
  db = { ...db, ...JSON.parse(await fs.readFile(DB_FILE, 'utf8')) };
} catch (error) {
  if (error.code !== 'ENOENT') console.error('Could not read database file:', error.message);
}
let writeQueue = Promise.resolve();
function saveDb() {
  writeQueue = writeQueue.then(async () => {
    const temp = `${DB_FILE}.tmp`;
    await fs.writeFile(temp, JSON.stringify(db, null, 2), { mode: 0o600 });
    await fs.rename(temp, DB_FILE);
  });
  return writeQueue;
}
const normalizeEmail = value => String(value || '').trim().toLowerCase();
const cleanText = (value, max = 2000) => String(value ?? '').trim().slice(0, max);
const isEmail = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
const hashOtp = (otp, salt) => crypto.createHash('sha256').update(`${otp}:${salt}`).digest('hex');
const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
};
function publicUser(user) {
  return { username: user.username, lastName: user.lastName, email: user.email };
}
function requireAuth(req, res, next) {
  const user = db.users.find(item => item.id === req.session.userId && item.verified);
  if (!user) return res.status(401).json({ error: 'Silakan login atau verifikasi akun terlebih dahulu.' });
  req.user = user;
  next();
}
function validatePassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 72;
}
async function sendOtpEmail(email, otp) {
  if (!process.env.BREVO_API_KEY || !process.env.BREVO_SENDER_EMAIL) {
    const err = new Error('Email OTP belum dikonfigurasi. Isi BREVO_API_KEY dan BREVO_SENDER_EMAIL di .env.');
    err.status = 503;
    throw err;
  }
  const response = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: {
      'accept': 'application/json',
      'api-key': process.env.BREVO_API_KEY,
      'content-type': 'application/json'
    },
    body: JSON.stringify({
      sender: { email: process.env.BREVO_SENDER_EMAIL, name: process.env.BREVO_SENDER_NAME || 'BlueBot AI' },
      to: [{ email }],
      subject: 'Kode verifikasi akun BlueBot AI',
      textContent: `Kode OTP kamu: ${otp}\nKode berlaku selama 10 menit. Jangan bagikan kode ini kepada siapa pun.`,
      htmlContent: `<div style="font-family:Arial,sans-serif;color:#172554;max-width:520px;margin:auto"><h2>Verifikasi email BlueBot AI</h2><p>Gunakan kode berikut untuk menyelesaikan pendaftaran:</p><div style="font-size:32px;font-weight:bold;letter-spacing:9px;padding:18px;background:#eff6ff;border-radius:12px;text-align:center">${otp}</div><p>Kode berlaku selama 10 menit. Jangan bagikan kode ini kepada siapa pun.</p></div>`
    })
  });
  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    console.error('Brevo API error:', response.status, detail.slice(0, 500));
    const err = new Error('Brevo gagal mengirim email. Periksa API key dan alamat sender yang sudah diverifikasi.');
    err.status = 502;
    throw err;
  }
}

app.get('/api/config', (_req, res) => {
  res.json({ aiConfigured: Boolean(process.env.AI_BASE_URL), modelConfigured: Boolean(process.env.AI_MODEL) });
});

app.post('/api/auth/register', authLimiter, otpLimiter, async (req, res) => {
  try {
    const username = cleanText(req.body.username, 32);
    const lastName = cleanText(req.body.lastName, 60);
    const email = normalizeEmail(req.body.email);
    const password = req.body.password;
    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) return res.status(400).json({ error: 'Username 3–32 karakter; gunakan huruf, angka, titik, garis bawah, atau tanda hubung.' });
    if (lastName.length < 1) return res.status(400).json({ error: 'Last name wajib diisi.' });
    if (!isEmail(email) || email.length > 254) return res.status(400).json({ error: 'Format email tidak valid.' });
    if (!validatePassword(password)) return res.status(400).json({ error: 'Password harus 8–72 karakter.' });
    if (db.users.some(u => u.email === email || u.username.toLowerCase() === username.toLowerCase())) {
      return res.status(409).json({ error: 'Email atau username sudah terdaftar. Silakan login.' });
    }
    const otp = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const salt = crypto.randomBytes(16).toString('hex');
    const pending = {
      id: crypto.randomUUID(), username, lastName, email,
      passwordHash: await bcrypt.hash(password, 12),
      otpHash: hashOtp(otp, salt), salt,
      expiresAt: Date.now() + OTP_TTL_MS, attempts: 0,
      lastSentAt: Date.now()
    };
    db.pending[email] = pending;
    await saveDb();
    try {
      await sendOtpEmail(email, otp);
    } catch (error) {
      delete db.pending[email];
      await saveDb();
      throw error;
    }
    res.json({ ok: true, email, message: 'Kode OTP dikirim. Periksa inbox atau folder spam.' });
  } catch (error) {
    res.status(error.status || 500).json({ error: error.status ? error.message : 'Pendaftaran gagal. Coba lagi nanti.' });
  }
});

app.post('/api/auth/resend-otp', otpLimiter, async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const pending = db.pending[email];
  if (!pending) return res.status(400).json({ error: 'Sesi pendaftaran tidak ditemukan. Daftar kembali.' });
  if (Date.now() - pending.lastSentAt < 60_000) return res.status(429).json({ error: 'Tunggu 60 detik sebelum meminta OTP baru.' });
  try {
    const otp = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const salt = crypto.randomBytes(16).toString('hex');
    pending.otpHash = hashOtp(otp, salt);
    pending.salt = salt;
    pending.expiresAt = Date.now() + OTP_TTL_MS;
    pending.attempts = 0;
    pending.lastSentAt = Date.now();
    await saveDb();
    await sendOtpEmail(email, otp);
    res.json({ ok: true, message: 'OTP baru sudah dikirim.' });
  } catch (error) {
    res.status(error.status || 500).json({ error: error.status ? error.message : 'Gagal mengirim ulang OTP.' });
  }
});

app.post('/api/auth/verify-otp', otpLimiter, async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const otp = String(req.body.otp || '').trim();
  const pending = db.pending[email];
  if (!pending) return res.status(400).json({ error: 'Sesi pendaftaran tidak ditemukan. Silakan daftar kembali.' });
  if (Date.now() > pending.expiresAt) {
    delete db.pending[email]; await saveDb();
    return res.status(400).json({ error: 'OTP kedaluwarsa. Silakan daftar kembali.' });
  }
  if (pending.attempts >= MAX_OTP_ATTEMPTS) {
    delete db.pending[email]; await saveDb();
    return res.status(429).json({ error: 'Batas percobaan OTP tercapai. Silakan daftar kembali.' });
  }
  pending.attempts++;
  if (!/^\d{6}$/.test(otp) || !safeEqual(hashOtp(otp, pending.salt), pending.otpHash)) {
    await saveDb();
    return res.status(400).json({ error: `OTP salah. Sisa percobaan: ${MAX_OTP_ATTEMPTS - pending.attempts}.` });
  }
  if (db.users.some(u => u.email === email || u.username.toLowerCase() === pending.username.toLowerCase())) {
    delete db.pending[email]; await saveDb();
    return res.status(409).json({ error: 'Email atau username sudah digunakan.' });
  }
  const user = {
    id: pending.id, username: pending.username, lastName: pending.lastName,
    email, passwordHash: pending.passwordHash, verified: true, createdAt: Date.now()
  };
  db.users.push(user);
  db.chats[user.id] = [];
  delete db.pending[email];
  await saveDb();
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Akun dibuat, tetapi sesi gagal dibuat. Silakan login.' });
    req.session.userId = user.id;
    req.session.save(saveErr => {
      if (saveErr) return res.status(500).json({ error: 'Akun dibuat, tetapi sesi gagal dibuat. Silakan login.' });
      res.json({ ok: true, user: publicUser(user) });
    });
  });
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const password = req.body.password;
  const user = db.users.find(u => u.email === email && u.verified);
  if (!user || typeof password !== 'string' || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: 'Email atau password salah.' });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Tidak dapat membuat sesi login.' });
    req.session.userId = user.id;
    req.session.save(saveErr => saveErr ? res.status(500).json({ error: 'Gagal menyimpan sesi.' }) : res.json({ ok: true, user: publicUser(user) }));
  });
});

app.get('/api/auth/me', (req, res) => {
  const user = db.users.find(item => item.id === req.session.userId && item.verified);
  if (!user) return res.status(401).json({ error: 'Belum login.' });
  res.json({ user: publicUser(user) });
});
app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('bluebot.sid', { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
    res.json({ ok: true });
  });
});

app.get('/api/chat/history', requireAuth, (req, res) => {
  res.json({ messages: (db.chats[req.user.id] || []).slice(-100) });
});
app.delete('/api/chat/history', requireAuth, async (req, res) => {
  db.chats[req.user.id] = [];
  await saveDb();
  res.json({ ok: true });
});

function getChatEndpoint() {
  const base = String(process.env.AI_BASE_URL || '').trim();
  if (!base) return null;
  const pathPart = process.env.AI_CHAT_COMPLETIONS_PATH || '/chat/completions';
  const normalizedBase = base.replace(/\/+$/, '');
  const normalizedPath = pathPart.startsWith('/') ? pathPart : `/${pathPart}`;
  if (normalizedBase.endsWith(normalizedPath)) return normalizedBase;
  return `${normalizedBase}${normalizedPath}`;
}
app.post('/api/chat', requireAuth, chatLimiter, async (req, res) => {
  const message = cleanText(req.body.message, 6000);
  if (!message) return res.status(400).json({ error: 'Pesan tidak boleh kosong.' });
  if (message.length > 6000) return res.status(413).json({ error: 'Pesan terlalu panjang.' });
  const endpoint = getChatEndpoint();
  if (!endpoint) return res.status(503).json({ error: 'AI belum dikonfigurasi. Isi AI_BASE_URL di file .env.' });
  const history = (db.chats[req.user.id] || []).slice(-12);
  const messages = [
    { role: 'system', content: process.env.AI_SYSTEM_PROMPT || 'You are a helpful AI assistant.' },
    ...history.map(item => ({ role: item.role, content: item.content })),
    { role: 'user', content: message }
  ];
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Math.max(5000, Number(process.env.AI_TIMEOUT_MS || 45000)));
  try {
    const headers = { 'content-type': 'application/json', 'accept': 'application/json' };
    const upstream = await fetch(endpoint, {
      method: 'POST', headers,
      body: JSON.stringify({ model: process.env.AI_MODEL || 'default', messages, temperature: 0.7 }),
      signal: controller.signal
    });
    const raw = await upstream.text();
    let payload;
    try { payload = JSON.parse(raw); } catch { payload = {}; }
    if (!upstream.ok) {
      console.error('AI endpoint error:', upstream.status, raw.slice(0, 700));
      return res.status(502).json({ error: `Layanan AI merespons HTTP ${upstream.status}. Periksa BASE_URL dan model endpoint yang mendukung akses tanpa API key.` });
    }
    const answer = payload?.choices?.[0]?.message?.content ?? payload?.message ?? payload?.response ?? payload?.output_text;
    if (typeof answer !== 'string' || !answer.trim()) {
      console.error('Unrecognized AI response shape:', JSON.stringify(payload).slice(0, 700));
      return res.status(502).json({ error: 'Format respons AI tidak dikenali. Endpoint harus kompatibel dengan format chat/completions atau perlu disesuaikan.' });
    }
    const now = Date.now();
    const store = db.chats[req.user.id] ||= [];
    store.push({ role: 'user', content: message, at: now }, { role: 'assistant', content: answer.trim(), at: Date.now() });
    db.chats[req.user.id] = store.slice(-200);
    await saveDb();
    res.json({ answer: answer.trim() });
  } catch (error) {
    res.status(error.name === 'AbortError' ? 504 : 502).json({
      error: error.name === 'AbortError' ? 'Permintaan AI terlalu lama. Coba lagi.' : 'Tidak dapat menghubungi endpoint AI. Periksa BASE_URL dan koneksi server.'
    });
  } finally {
    clearTimeout(timeout);
  }
});

app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route tidak ditemukan.' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log(`BlueBot AI running at http://localhost:${PORT}`));
